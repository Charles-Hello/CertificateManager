#!/system/bin/sh

# 证书管理器WebUI服务启动脚本

MODDIR="$(cd "$(dirname "$0")" && pwd)"
WEB_SERVER="$MODDIR/scripts/web_server.sh"
LOG_FILE="/data/local/tmp/cert_manager_webui.log"
PID_FILE="/data/local/tmp/cert_manager_webui.pid"

# 等待系统完全启动
sleep 15

# 创建日志目录
mkdir -p "$(dirname "$LOG_FILE")"
echo "[$(date)] Certificate Manager service starting..." >> "$LOG_FILE"

# 清理旧的进程和PID文件
if [ -f "$PID_FILE" ]; then
    old_pid=$(cat "$PID_FILE")
    if kill -0 "$old_pid" 2>/dev/null; then
        echo "[$(date)] Killing old process: $old_pid" >> "$LOG_FILE"
        kill "$old_pid" 2>/dev/null
        sleep 2
    fi
    rm -f "$PID_FILE"
fi

# 确保web服务器脚本存在且可执行
if [ ! -f "$WEB_SERVER" ]; then
    echo "[$(date)] Error: Web server script not found: $WEB_SERVER" >> "$LOG_FILE"
    exit 1
fi

# chmod 755 "$WEB_SERVER"  # 在Android存储中可能无法设置执行权限

# 启动web服务器
echo "[$(date)] Starting web server..." >> "$LOG_FILE"
nohup sh "$WEB_SERVER" >> "$LOG_FILE" 2>&1 &
new_pid=$!

# 保存新的PID
echo "$new_pid" > "$PID_FILE"
echo "[$(date)] WebUI started with PID: $new_pid" >> "$LOG_FILE"
echo "[$(date)] Access URL: http://localhost:18888" >> "$LOG_FILE"

# 验证服务是否启动成功
sleep 5
if kill -0 "$new_pid" 2>/dev/null; then
    echo "[$(date)] WebUI service started successfully" >> "$LOG_FILE"
else
    echo "[$(date)] WebUI service failed to start" >> "$LOG_FILE"
    rm -f "$PID_FILE"
fi

echo "[$(date)] Certificate Manager service script completed" >> "$LOG_FILE"