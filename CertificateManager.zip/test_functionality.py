#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json
import tempfile
import os
import time
from datetime import datetime

# 配置
BASE_URL = "http://localhost:18888"
TEST_CERT_CONTENT = """-----BEGIN CERTIFICATE-----
MIIDXTCCAkWgAwIBAgIJALkqEtJ5EjvKMA0GCSqGSIb3DQEBCwUAMEUxCzAJBgNV
BAYTAkNOMQswCQYDVQQIDAJCSjEOMAwGA1UEBwwFVGVzdDE5MQswCQYDVQQKDAJU
ZXN0MQwwCgYDVQQDDANUZXN0MB4XDTI0MDEwMTAwMDAwMFoXDTI1MDEwMTAwMDAw
MFowRTELMAkGA1UEBhMCQ04xCzAJBgNVBAgMAkJKMQ4wDAYDVQQHDAVUZXN0MQsw
CQYDVQQKDAJUZXN0MQwwCgYDVQQDDANUZXN0MIIBIjANBgkqhkiG9w0BAQEFAAOC
AQ8AMIIBCgKCAQEAxaLwZj5GaGhqYmJVVh8I2k1zVy1p9/dRpI6jdXXXXXXXXXX
XQIDAQAB
-----END CERTIFICATE-----"""

class CertManagerTester:
    def __init__(self):
        self.session = requests.Session()
        self.test_results = []
        self.added_certs = []  # 跟踪添加的证书，便于清理
        
    def log(self, message, status="INFO"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        print(f"[{timestamp}] [{status}] {message}")
        
    def test_api_request(self, method, endpoint, data=None, expected_status=200):
        """测试API请求"""
        url = f"{BASE_URL}{endpoint}"
        try:
            if method == "GET":
                response = self.session.get(url)
            elif method == "POST":
                response = self.session.post(url, 
                    headers={"Content-Type": "application/json"},
                    data=json.dumps(data) if data else None)
            
            if response.status_code == expected_status:
                try:
                    return True, response.json()
                except:
                    return True, response.text
            else:
                return False, f"HTTP {response.status_code}: {response.text}"
                
        except Exception as e:
            return False, str(e)
    
    def test_basic_connectivity(self):
        """测试基础连接"""
        self.log("测试基础连接...")
        
        success, result = self.test_api_request("GET", "/")
        if success and "CA证书管理器" in str(result):
            self.log("✅ 基础连接测试通过", "SUCCESS")
            return True
        else:
            self.log(f"❌ 基础连接测试失败: {result}", "ERROR")
            return False
    
    def test_paths_api(self):
        """测试路径信息API"""
        self.log("测试路径信息API...")
        
        success, result = self.test_api_request("GET", "/api/paths")
        if success:
            paths = result
            required_fields = ["moddir", "cert_dir", "config_dir", "android_sdk", "need_apex_mount"]
            
            missing_fields = [field for field in required_fields if field not in paths]
            if missing_fields:
                self.log(f"❌ 路径API缺少字段: {missing_fields}", "ERROR")
                return False
            
            self.log(f"✅ 路径API测试通过", "SUCCESS")
            self.log(f"   Android SDK: {paths['android_sdk']}")
            self.log(f"   需要APEX挂载: {paths['need_apex_mount']}")
            if paths['need_apex_mount'] == 'true':
                self.log(f"   APEX证书目录: {paths.get('apex_cert_dir', '未配置')}")
            return True
        else:
            self.log(f"❌ 路径API测试失败: {result}", "ERROR")
            return False
    
    def test_certificates_api(self):
        """测试证书列表API"""
        self.log("测试证书列表API...")
        
        success, result = self.test_api_request("GET", "/api/certificates")
        if success:
            certs = result
            required_fields = ["certificates", "total_certs", "enabled_certs", "status"]
            
            missing_fields = [field for field in required_fields if field not in certs]
            if missing_fields:
                self.log(f"❌ 证书API缺少字段: {missing_fields}", "ERROR")
                return False
            
            self.log(f"✅ 证书API测试通过", "SUCCESS")
            self.log(f"   总计证书: {certs['total_certs']}")
            self.log(f"   已启用证书: {certs['enabled_certs']}")
            self.log(f"   系统状态: {certs['status']}")
            
            # 检查证书详细信息
            for cert in certs['certificates']:
                self.log(f"   证书: {cert['name']} - 状态: {'已启用' if cert['enabled'] else '已禁用'}")
            
            return True
        else:
            self.log(f"❌ 证书API测试失败: {result}", "ERROR")
            return False
    
    def test_add_cert_by_path(self):
        """测试通过文件路径添加证书"""
        self.log("测试通过文件路径添加证书...")
        
        # 创建临时证书文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.pem', delete=False) as tmp_file:
            tmp_file.write(TEST_CERT_CONTENT)
            cert_path = tmp_file.name
        
        try:
            success, result = self.test_api_request("POST", "/api/add_cert", {
                "cert_path": cert_path
            })
            
            if success and result.get("success"):
                self.log("✅ 路径添加证书测试通过", "SUCCESS")
                # 记录添加的证书用于后续清理
                cert_name = os.path.basename(cert_path)
                self.added_certs.append(cert_name.replace('.pem', '.0'))
                return True
            else:
                self.log(f"❌ 路径添加证书测试失败: {result}", "ERROR")
                return False
        finally:
            # 清理临时文件
            try:
                os.unlink(cert_path)
            except:
                pass
    
    def test_upload_cert(self):
        """测试上传证书内容"""
        self.log("测试上传证书内容...")
        
        success, result = self.test_api_request("POST", "/api/upload_cert", {
            "cert_content": TEST_CERT_CONTENT,
            "cert_name": "test_upload.pem"
        })
        
        if success and result.get("success"):
            self.log("✅ 上传证书测试通过", "SUCCESS")
            # 记录添加的证书用于后续清理
            self.added_certs.append("test_upload.0")
            return True
        else:
            self.log(f"❌ 上传证书测试失败: {result}", "ERROR")
            return False
    
    def test_apply_config(self):
        """测试应用配置"""
        self.log("测试应用配置...")
        
        success, result = self.test_api_request("POST", "/api/apply_config")
        
        if success and result.get("success"):
            self.log("✅ 应用配置测试通过", "SUCCESS")
            return True
        else:
            self.log(f"❌ 应用配置测试失败: {result}", "ERROR")
            return False
    
    def test_cert_persistence(self):
        """测试证书持久化"""
        self.log("测试证书持久化...")
        
        # 获取添加证书前的数量
        success, before_result = self.test_api_request("GET", "/api/certificates")
        if not success:
            self.log("❌ 无法获取初始证书列表", "ERROR")
            return False
        
        before_count = before_result["total_certs"]
        
        # 添加一个测试证书
        success, add_result = self.test_api_request("POST", "/api/upload_cert", {
            "cert_content": TEST_CERT_CONTENT,
            "cert_name": "persistence_test.pem"
        })
        
        if not success or not add_result.get("success"):
            self.log("❌ 添加测试证书失败", "ERROR")
            return False
        
        # 等待一下确保数据写入
        time.sleep(1)
        
        # 重新获取证书列表
        success, after_result = self.test_api_request("GET", "/api/certificates")
        if not success:
            self.log("❌ 无法获取更新后的证书列表", "ERROR")
            return False
        
        after_count = after_result["total_certs"]
        
        if after_count == before_count + 1:
            self.log("✅ 证书持久化测试通过", "SUCCESS")
            self.log(f"   证书数量从 {before_count} 增加到 {after_count}")
            # 记录添加的证书用于清理
            self.added_certs.append("persistence_test.0")
            return True
        else:
            self.log(f"❌ 证书持久化测试失败: 期望数量 {before_count + 1}, 实际 {after_count}", "ERROR")
            return False
    
    def test_dual_directory_support(self):
        """测试双目录支持"""
        self.log("测试双目录支持...")
        
        # 获取路径信息
        success, paths = self.test_api_request("GET", "/api/paths")
        if not success:
            self.log("❌ 无法获取路径信息", "ERROR")
            return False
        
        need_apex = paths.get("need_apex_mount") == "true"
        cert_dir = paths.get("cert_dir", "").replace("/scripts/..", "")
        apex_cert_dir = paths.get("apex_cert_dir", "").replace("/scripts/..", "")
        
        self.log(f"   需要APEX挂载: {need_apex}")
        self.log(f"   传统证书目录: {cert_dir}")
        
        if need_apex:
            self.log(f"   APEX证书目录: {apex_cert_dir}")
            
            # 检查是否真的创建了APEX目录
            try:
                import subprocess
                result = subprocess.run(["ls", apex_cert_dir], 
                                      capture_output=True, text=True)
                if result.returncode == 0:
                    self.log("✅ APEX目录已创建", "SUCCESS")
                else:
                    self.log("❌ APEX目录不存在", "ERROR")
                    return False
            except Exception as e:
                self.log(f"❌ 检查APEX目录失败: {e}", "ERROR")
                return False
        
        self.log("✅ 双目录支持测试通过", "SUCCESS")
        return True
    
    def cleanup_test_certs(self):
        """清理测试证书"""
        self.log("清理测试证书...")
        
        for cert_id in self.added_certs:
            success, result = self.test_api_request("POST", "/api/remove_cert", {
                "cert_id": cert_id
            })
            if success:
                self.log(f"   已清理: {cert_id}")
            else:
                self.log(f"   清理失败: {cert_id} - {result}", "WARN")
    
    def run_all_tests(self):
        """运行所有测试"""
        self.log("=== 开始证书管理器功能测试 ===")
        
        tests = [
            ("基础连接", self.test_basic_connectivity),
            ("路径信息API", self.test_paths_api),
            ("证书列表API", self.test_certificates_api),
            ("双目录支持", self.test_dual_directory_support),
            ("路径添加证书", self.test_add_cert_by_path),
            ("上传证书", self.test_upload_cert),
            ("证书持久化", self.test_cert_persistence),
            ("应用配置", self.test_apply_config),
        ]
        
        passed = 0
        total = len(tests)
        
        for test_name, test_func in tests:
            self.log(f"\n--- 测试: {test_name} ---")
            try:
                if test_func():
                    passed += 1
                time.sleep(0.5)  # 短暂延迟避免请求过快
            except Exception as e:
                self.log(f"❌ 测试 {test_name} 出现异常: {e}", "ERROR")
        
        self.log(f"\n=== 测试完成 ===")
        self.log(f"通过: {passed}/{total} ({passed/total*100:.1f}%)")
        
        if passed == total:
            self.log("🎉 所有测试都通过了！", "SUCCESS")
        else:
            self.log(f"⚠️  有 {total-passed} 个测试失败", "WARN")
        
        # 清理测试数据
        if self.added_certs:
            self.log("\n--- 清理测试数据 ---")
            self.cleanup_test_certs()
        
        return passed == total

if __name__ == "__main__":
    tester = CertManagerTester()
    success = tester.run_all_tests()
    exit(0 if success else 1)