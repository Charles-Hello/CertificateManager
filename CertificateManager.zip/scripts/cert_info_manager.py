#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
证书信息管理器
专门用于管理 cert_info.json 文件的增删改查操作
"""

import json
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional, Any

class CertInfoManager:
    def __init__(self, info_file_path: str):
        self.info_file = info_file_path
        self.ensure_file_exists()
    
    def ensure_file_exists(self):
        """确保JSON文件存在并具有正确的结构"""
        if not os.path.exists(self.info_file):
            self.save_data({"certificates": []})
        else:
            try:
                with open(self.info_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if not isinstance(data, dict) or 'certificates' not in data:
                        self.save_data({"certificates": []})
            except (json.JSONDecodeError, IOError):
                self.save_data({"certificates": []})
    
    def load_data(self) -> Dict[str, Any]:
        """加载JSON数据"""
        try:
            with open(self.info_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if not isinstance(data.get('certificates'), list):
                    data['certificates'] = []
                return data
        except (json.JSONDecodeError, IOError, FileNotFoundError):
            return {"certificates": []}
    
    def save_data(self, data: Dict[str, Any]):
        """保存JSON数据"""
        try:
            # 创建备份
            if os.path.exists(self.info_file):
                backup_file = f"{self.info_file}.backup"
                try:
                    with open(self.info_file, 'r') as src, open(backup_file, 'w') as dst:
                        dst.write(src.read())
                except:
                    pass
            
            # 保存新数据
            with open(self.info_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            return True
        except IOError as e:
            print(f"Error saving data: {e}", file=sys.stderr)
            return False
    
    def add_certificate(self, cert_hash: str, filename: str, original_path: str, 
                       enabled: bool = True, timestamp: Optional[str] = None) -> bool:
        """添加或更新证书信息"""
        if not timestamp:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        data = self.load_data()
        
        # 移除相同filename的现有条目
        data['certificates'] = [cert for cert in data['certificates'] 
                              if cert.get('filename') != filename]
        
        # 添加新证书
        new_cert = {
            "hash": cert_hash,
            "filename": filename,
            "original_path": original_path,
            "added_time": timestamp,
            "enabled": enabled,
            "source": "user_added"
        }
        
        data['certificates'].append(new_cert)
        
        return self.save_data(data)
    
    def remove_certificate(self, cert_identifier: str, by_filename: bool = False) -> bool:
        """移除证书信息
        
        Args:
            cert_identifier: 证书标识符（hash或filename）
            by_filename: 如果为True，则按文件名移除；否则按hash移除
        """
        data = self.load_data()
        original_count = len(data['certificates'])
        
        if by_filename:
            data['certificates'] = [cert for cert in data['certificates'] 
                                  if cert.get('filename') != cert_identifier]
        else:
            data['certificates'] = [cert for cert in data['certificates'] 
                                  if cert.get('hash') != cert_identifier]
        
        removed = len(data['certificates']) < original_count
        
        if removed:
            return self.save_data(data)
        return False
    
    def get_certificate(self, cert_identifier: str, by_filename: bool = False) -> Optional[Dict[str, Any]]:
        """获取特定证书信息
        
        Args:
            cert_identifier: 证书标识符（hash或filename）
            by_filename: 如果为True，则按文件名查找；否则按hash查找
        """
        data = self.load_data()
        for cert in data['certificates']:
            if by_filename:
                if cert.get('filename') == cert_identifier:
                    return cert
            else:
                if cert.get('hash') == cert_identifier:
                    return cert
        return None
    
    def list_certificates(self) -> List[Dict[str, Any]]:
        """获取所有证书信息"""
        data = self.load_data()
        certificates = data['certificates']
        
        # 增强证书信息，添加文件大小和位置信息
        for cert in certificates:
            # 添加文件大小信息
            cert_path = self._find_cert_file_by_hash(cert)
            if cert_path and os.path.exists(cert_path):
                try:
                    cert['file_size'] = os.path.getsize(cert_path)
                    cert['location'] = 'dev' if '/system/etc/security/cacerts' in cert_path else 'running'
                except OSError:
                    cert['file_size'] = 0
                    cert['location'] = 'unknown'
            else:
                cert['file_size'] = 0
                cert['location'] = 'unknown'
                
            # 确保有name字段
            if 'name' not in cert:
                cert['name'] = cert.get('filename', 'Unknown')
        
        return certificates
    
    def _find_cert_file(self, filename: str) -> Optional[str]:
        """查找证书文件的实际路径"""
        if not filename:
            return None
            
        # 从当前文件位置推断模块目录
        script_dir = os.path.dirname(os.path.abspath(__file__))
        moddir = os.path.dirname(script_dir)
        
        # 可能的证书目录
        cert_dirs = [
            os.path.join(moddir, 'system', 'etc', 'security', 'cacerts'),
            os.path.join(moddir, 'apex', 'com.android.conscrypt', 'cacerts'),
            '/data/adb/modules/CertificateManager/system/etc/security/cacerts',
            '/data/adb/modules/CertificateManager/apex/com.android.conscrypt/cacerts'
        ]
        
        # 首先尝试直接按文件名查找
        for cert_dir in cert_dirs:
            path = os.path.join(cert_dir, filename)
            if os.path.exists(path):
                return path
        
        # 如果直接查找失败，扫描目录寻找第一个.0文件
        # 这是为了处理filename是hash但实际文件名不同的情况
        for cert_dir in cert_dirs:
            if os.path.exists(cert_dir):
                try:
                    for file in os.listdir(cert_dir):
                        if file.endswith('.0'):
                            return os.path.join(cert_dir, file)
                except OSError:
                    continue
        
        return None
    
    def _find_cert_file_by_hash(self, cert_info: Dict[str, Any]) -> Optional[str]:
        """通过证书信息查找对应的文件路径"""
        # 从当前文件位置推断模块目录
        script_dir = os.path.dirname(os.path.abspath(__file__))
        moddir = os.path.dirname(script_dir)
        
        # 可能的证书目录
        cert_dirs = [
            os.path.join(moddir, 'system', 'etc', 'security', 'cacerts'),
            os.path.join(moddir, 'apex', 'com.android.conscrypt', 'cacerts')
        ]
        
        cert_hash = cert_info.get('hash', '')
        original_filename = os.path.basename(cert_info.get('original_path', ''))
        computed_filename = cert_info.get('filename', '')
        
        # 尝试多种文件名匹配策略
        possible_filenames = [
            computed_filename,  # 计算出的文件名
            original_filename,  # 原始文件名
            f"{cert_hash}.0"    # hash + .0
        ]
        
        for cert_dir in cert_dirs:
            if not os.path.exists(cert_dir):
                continue
                
            # 尝试每种可能的文件名
            for filename in possible_filenames:
                if filename:
                    path = os.path.join(cert_dir, filename)
                    if os.path.exists(path):
                        return path
            
            # 如果以上都失败，尝试通过文件内容匹配
            # 读取original_path的内容并与目录中的文件比较
            original_path = cert_info.get('original_path', '')
            if original_path and os.path.exists(original_path):
                try:
                    with open(original_path, 'rb') as f:
                        original_content = f.read()
                    
                    for file in os.listdir(cert_dir):
                        if file.endswith('.0'):
                            file_path = os.path.join(cert_dir, file)
                            try:
                                with open(file_path, 'rb') as f:
                                    file_content = f.read()
                                if file_content == original_content:
                                    return file_path
                            except OSError:
                                continue
                except OSError:
                    pass
        
        return None
    
    def get_stats(self) -> Dict[str, int]:
        """获取统计信息"""
        certificates = self.list_certificates()
        total = len(certificates)
        enabled = sum(1 for cert in certificates if cert.get('enabled', False))
        return {"total": total, "enabled": enabled}
    
    def update_certificate_status(self, cert_identifier: str, enabled: bool, by_filename: bool = False) -> bool:
        """更新证书启用状态
        
        Args:
            cert_identifier: 证书标识符（hash或filename）
            enabled: 启用状态
            by_filename: 如果为True，则按文件名查找；否则按hash查找
        """
        data = self.load_data()
        for cert in data['certificates']:
            if by_filename:
                if cert.get('filename') == cert_identifier:
                    cert['enabled'] = enabled
                    return self.save_data(data)
            else:
                if cert.get('hash') == cert_identifier:
                    cert['enabled'] = enabled
                    return self.save_data(data)
        return False
    
    def rebuild_from_directory(self, cert_directory: str) -> bool:
        """从证书目录重建JSON文件"""
        if not os.path.exists(cert_directory):
            return False
        
        new_data = {"certificates": []}
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 扫描证书目录
        try:
            for filename in os.listdir(cert_directory):
                if filename.endswith('.0'):
                    cert_hash = filename[:-2]  # 去掉.0后缀
                    cert_path = os.path.join(cert_directory, filename)
                    
                    cert_info = {
                        "hash": cert_hash,
                        "filename": filename,
                        "original_path": f"rebuilt_from_{cert_directory}",
                        "added_time": timestamp,
                        "enabled": True,
                        "source": "directory_rebuild"
                    }
                    
                    new_data['certificates'].append(cert_info)
            
            return self.save_data(new_data)
        except OSError as e:
            print(f"Error reading directory {cert_directory}: {e}", file=sys.stderr)
            return False


def main():
    """命令行接口"""
    if len(sys.argv) < 3:
        print("用法: python3 cert_info_manager.py <info_file> <command> [args...]")
        print("命令:")
        print("  add <hash> <filename> <original_path> [enabled] [timestamp]")
        print("  remove <hash|filename> [--by-filename]") 
        print("  get <hash|filename> [--by-filename]")
        print("  list")
        print("  stats")
        print("  update_status <hash|filename> <enabled> [--by-filename]")
        print("  rebuild <cert_directory>")
        sys.exit(1)
    
    info_file = sys.argv[1]
    command = sys.argv[2]
    
    manager = CertInfoManager(info_file)
    
    if command == "add":
        if len(sys.argv) < 6:
            print("add命令需要: hash filename original_path [enabled] [timestamp]")
            sys.exit(1)
        
        cert_hash = sys.argv[3]
        filename = sys.argv[4] 
        original_path = sys.argv[5]
        enabled = sys.argv[6].lower() == "true" if len(sys.argv) > 6 else True
        timestamp = sys.argv[7] if len(sys.argv) > 7 else None
        
        if manager.add_certificate(cert_hash, filename, original_path, enabled, timestamp):
            print("Certificate added successfully")
        else:
            print("Failed to add certificate")
            sys.exit(1)
    
    elif command == "remove":
        if len(sys.argv) < 4:
            print("remove命令需要: hash|filename [--by-filename]")
            sys.exit(1)
        
        cert_identifier = sys.argv[3]
        by_filename = "--by-filename" in sys.argv
        
        if manager.remove_certificate(cert_identifier, by_filename):
            print("Certificate removed successfully")
        else:
            print("Certificate not found or failed to remove")
            sys.exit(1)
    
    elif command == "get":
        if len(sys.argv) < 4:
            print("get命令需要: hash|filename [--by-filename]")
            sys.exit(1)
        
        cert_identifier = sys.argv[3]
        by_filename = "--by-filename" in sys.argv
        
        cert = manager.get_certificate(cert_identifier, by_filename)
        if cert:
            print(json.dumps(cert, indent=2, ensure_ascii=False))
        else:
            print("Certificate not found")
            sys.exit(1)
    
    elif command == "list":
        certificates = manager.list_certificates()
        print(json.dumps({"certificates": certificates}, indent=2, ensure_ascii=False))
    
    elif command == "stats":
        stats = manager.get_stats()
        print(json.dumps(stats, indent=2, ensure_ascii=False))
    
    elif command == "update_status":
        if len(sys.argv) < 5:
            print("update_status命令需要: hash|filename enabled [--by-filename]")
            sys.exit(1)
        
        cert_identifier = sys.argv[3]
        enabled = sys.argv[4].lower() == "true"
        by_filename = "--by-filename" in sys.argv
        
        if manager.update_certificate_status(cert_identifier, enabled, by_filename):
            print("Status updated successfully")
        else:
            print("Certificate not found or failed to update")
            sys.exit(1)
    
    elif command == "rebuild":
        if len(sys.argv) < 4:
            print("rebuild命令需要: cert_directory")
            sys.exit(1)
        
        cert_directory = sys.argv[3]
        if manager.rebuild_from_directory(cert_directory):
            print("JSON file rebuilt successfully")
        else:
            print("Failed to rebuild JSON file")
            sys.exit(1)
    
    else:
        print(f"未知命令: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()