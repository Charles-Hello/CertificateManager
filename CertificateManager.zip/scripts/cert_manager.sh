#!/system/bin/sh

# 证书管理器核心脚本
# 用于添加、删除、列出和管理CA证书

# 使用绝对路径，确保与post-fs-data.sh一致
MODDIR="/data/adb/modules/CertificateManager"
CERT_DIR="$MODDIR/system/etc/security/cacerts"
APEX_CERT_DIR="$MODDIR/apex/com.android.conscrypt/cacerts"
CONFIG_DIR="$MODDIR/config"
ENABLED_FILE="$CONFIG_DIR/enabled_certs.txt"
INFO_FILE="$CONFIG_DIR/cert_info.json"

# 检查Android版本以确定是否需要APEX挂载
ANDROID_SDK=$(getprop ro.build.version.sdk)
NEED_APEX_MOUNT=false
if [ "$ANDROID_SDK" -ge 34 ]; then
    NEED_APEX_MOUNT=true
fi

# 确保目录存在
mkdir -p "$CERT_DIR" "$CONFIG_DIR"
if [ "$NEED_APEX_MOUNT" = "true" ]; then
    mkdir -p "$APEX_CERT_DIR"
fi
touch "$ENABLED_FILE"

log() {
    echo "[$(date '+%H:%M:%S')] $1"
}

# 生成证书哈希
generate_hash() {
    local cert_file="$1"
    if [ -f "$cert_file" ]; then
        local filename="$(basename "$cert_file")"
        local basename_no_ext="${filename%.*}"  # 去掉任何扩展名
        
        # 检查文件名是否已经是8字符十六进制哈希
        if echo "$basename_no_ext" | grep -q '^[a-f0-9]\{8\}$'; then
            echo "$basename_no_ext"
            return
        fi
        
        # 尝试使用openssl计算真实哈希
        if command -v openssl >/dev/null 2>&1; then
            local real_hash=$(openssl x509 -in "$cert_file" -noout -hash 2>/dev/null)
            if [ -n "$real_hash" ] && [ "$real_hash" != "" ]; then
                echo "$real_hash"
                return
            fi
        fi
        
        # 如果openssl不可用，使用基于完整内容+时间戳的哈希
        local timestamp=$(date +%s%N)  # 纳秒时间戳确保唯一性
        local content_with_time="${cert_file}_${timestamp}_$(cat "$cert_file" 2>/dev/null)"
        local content_hash=$(echo "$content_with_time" | md5sum 2>/dev/null | cut -c1-8)
        if [ -n "$content_hash" ]; then
            echo "$content_hash"
        else
            # 最后的fallback：基于文件名+时间戳生成
            local fallback_hash=$(echo "${basename_no_ext}_${timestamp}" | md5sum 2>/dev/null | cut -c1-8)
            if [ -n "$fallback_hash" ]; then
                echo "$fallback_hash"
            else
                echo "$(printf "%08x" $RANDOM$RANDOM)"  # 随机16进制
            fi
        fi
    else
        echo "unknown"
    fi
}



# 获取证书详细信息
get_cert_info() {
    local hash="$1"
    
    if [ -f "$INFO_FILE" ]; then
        # 简单的JSON查找
        grep -A 10 "\"hash\": \"$hash\"" "$INFO_FILE" 2>/dev/null
    fi
}

# 添加证书
add_cert() {
    local cert_path="$1"
    
    if [ ! -f "$cert_path" ]; then
        log "错误: 证书文件不存在: $cert_path"
        return 1
    fi
    
    # 跳过证书格式验证，直接处理文件
    
    local cert_name="$(basename "$cert_path")"
    local hash="$(generate_hash "$cert_path")"
    local target_file="$CERT_DIR/${hash}.0"
    local timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    
    # 复制证书文件到传统位置 - 遵循系统证书权限标准
    cp "$cert_path" "$target_file"
    chmod 644 "$target_file"
    chown 0:0 "$target_file" 2>/dev/null || true  # 设置为 root:root，忽略权限错误
    
    # 如果需要，同时复制到APEX位置 (Android 14+)
    if [ "$NEED_APEX_MOUNT" = "true" ]; then
        local apex_target_file="$APEX_CERT_DIR/${hash}.0"
        cp "$cert_path" "$apex_target_file"
        chmod 644 "$apex_target_file"
        chown 0:0 "$apex_target_file" 2>/dev/null || true  # 设置为 root:root，忽略权限错误
        log "证书已复制到APEX目录: ${hash}.0"
    fi
    
    # 添加到启用列表（使用原始文件名，避免重复）
    local cert_basename="$(basename "$cert_path")"
    if ! grep -Fx "$cert_basename" "$ENABLED_FILE" 2>/dev/null; then
        echo "$cert_basename" >> "$ENABLED_FILE"
        log "添加到启用列表: $cert_basename"
    else
        log "证书已在启用列表中: $cert_basename"
    fi
    
    # 证书元数据将由simple_server.py直接管理
    
    log "证书添加成功: $cert_name -> ${hash}.0"
    echo "Certificate $cert_name added successfully"
    return 0
}

# 删除证书
remove_cert() {
    local cert_id="$1"
    local removed=false
    
    # 从系统目录删除
    for cert_file in "$CERT_DIR"/*.0; do
        [ -f "$cert_file" ] || continue
        local basename_cert="$(basename "$cert_file")"
        if [ "$basename_cert" = "$cert_id" ] || [ "${basename_cert%.0}" = "$cert_id" ]; then
            rm -f "$cert_file"
            log "删除证书文件: $basename_cert"
            removed=true
        fi
    done
    
    # 从APEX目录删除 (Android 14+)
    if [ "$NEED_APEX_MOUNT" = "true" ]; then
        for cert_file in "$APEX_CERT_DIR"/*.0; do
            [ -f "$cert_file" ] || continue
            local basename_cert="$(basename "$cert_file")"
            if [ "$basename_cert" = "$cert_id" ] || [ "${basename_cert%.0}" = "$cert_id" ]; then
                rm -f "$cert_file"
                log "删除APEX证书文件: $basename_cert"
                removed=true
            fi
        done
    fi
    
    # 从启用列表删除
    if [ -f "$ENABLED_FILE" ]; then
        sed -i "/$cert_id/d" "$ENABLED_FILE"
    fi
    
    if [ "$removed" = true ]; then
        log "证书删除成功: $cert_id"
        echo "Certificate $cert_id removed successfully"
    else
        log "警告: 未找到证书: $cert_id"
        echo "Certificate $cert_id not found"
    fi
}

# 列出证书
list_certs() {
    log "系统证书列表:"
    echo "=== 系统证书 ==="
    
    local count=0
    for cert_file in "$CERT_DIR"/*.0; do
        [ -f "$cert_file" ] || continue
        local cert_name="$(basename "$cert_file")"
        local hash="${cert_name%.0}"
        local enabled="否"
        
        # 检查启用状态（支持.0文件名、哈希或原始文件名）
        if grep -q "$cert_name\|${cert_name%.0}\|$hash" "$ENABLED_FILE" 2>/dev/null; then
            enabled="是"
        fi
        
        echo "文件: $cert_name"
        echo "哈希: $hash"  
        echo "启用: $enabled"
        echo "---"
        count=$((count + 1))
    done
    
    echo "总计: $count 个证书"
}

# SELinux上下文设置函数（学习自post-fs-data.sh）
set_context() {
    [ "$(getenforce)" = "Enforcing" ] || return 0

    local target_dir="$1"
    local source_dir="$2"
    local default_selinux_context=u:object_r:system_file:s0
    local selinux_context=$(ls -Zd "$target_dir" | awk '{print $1}' 2>/dev/null)

    if [ -n "$selinux_context" ] && [ "$selinux_context" != "?" ]; then
        chcon -R "$selinux_context" "$source_dir"
        log "设置SELinux上下文: $selinux_context"
    else
        chcon -R "$default_selinux_context" "$source_dir"
        log "使用默认SELinux上下文: $default_selinux_context"
    fi
}

# 挂载传统证书目录（Android 13及以下）
mount_legacy_certs() {
    log "挂载传统证书目录 /system/etc/security/cacerts"
    
    # 设置SELinux上下文
    set_context /system/etc/security/cacerts "$CERT_DIR"
    
    # 直接通过Magisk模块系统挂载（无需手动mount）
    log "传统证书目录挂载完成"
    return 0
}

# 挂载APEX证书目录（Android 14+）
mount_apex_certs() {
    log "挂载APEX证书目录 /apex/com.android.conscrypt/cacerts"
    
    # 检查APEX目录是否存在
    if [ ! -d /apex/com.android.conscrypt/cacerts ]; then
        log "错误: APEX证书目录不存在"
        return 1
    fi
    
    # 检查模块证书目录
    if [ ! -d "$CERT_DIR" ] || [ -z "$(ls -A "$CERT_DIR" 2>/dev/null)" ]; then
        log "警告: 没有找到要安装的证书"
        return 1
    fi
    
    # 创建临时目录
    local TEMP_DIR=/data/local/tmp/cacerts-copy-$$
    rm -rf "$TEMP_DIR"
    mkdir -p -m 700 "$TEMP_DIR"
    
    # 挂载tmpfs到临时目录
    if ! mount -t tmpfs tmpfs "$TEMP_DIR"; then
        log "错误: 无法创建tmpfs"
        rmdir "$TEMP_DIR"
        return 1
    fi
    
    # 复制原系统证书到临时目录
    if ! cp -f /apex/com.android.conscrypt/cacerts/* "$TEMP_DIR/" 2>/dev/null; then
        log "警告: 复制系统证书时出现问题"
    fi
    
    # 复制用户配置的证书到临时目录
    local installed_count=0
    for cert_file in "$CERT_DIR"/*.0; do
        [ -f "$cert_file" ] || continue
        local cert_name=$(basename "$cert_file")
        log "安装证书: $cert_name"
        if cp -f "$cert_file" "$TEMP_DIR/"; then
            installed_count=$((installed_count + 1))
        else
            log "警告: 复制证书失败: $cert_name"
        fi
    done
    
    # 设置权限和SELinux上下文
    chown -R 0:0 "$TEMP_DIR"
    set_context /apex/com.android.conscrypt/cacerts "$TEMP_DIR"
    
    # 检查证书数量
    local CERTS_NUM="$(ls -1 "$TEMP_DIR" | wc -l)"
    log "临时目录中的证书总数: $CERTS_NUM"
    
    if [ "$CERTS_NUM" -gt 10 ]; then
        # 绑定挂载到APEX目录
        if mount -o bind "$TEMP_DIR" /apex/com.android.conscrypt/cacerts; then
            log "主挂载成功"
            
            # 为所有相关进程设置挂载
            for pid in 1 $(pgrep zygote 2>/dev/null) $(pgrep zygote64 2>/dev/null); do
                if [ -d "/proc/$pid/ns/mnt" ]; then
                    if nsenter --mount=/proc/$pid/ns/mnt -- \
                        mount --bind "$TEMP_DIR" /apex/com.android.conscrypt/cacerts 2>/dev/null; then
                        log "为进程 $pid 设置挂载成功"
                    else
                        log "警告: 为进程 $pid 设置挂载失败"
                    fi
                fi
            done
            
            log "APEX证书挂载完成，已安装 $installed_count 个证书"
            return 0
        else
            log "错误: 绑定挂载失败"
            umount "$TEMP_DIR" 2>/dev/null
            rmdir "$TEMP_DIR"
            return 1
        fi
    else
        log "错误: 证书数量不足，挂载失败"
        umount "$TEMP_DIR" 2>/dev/null
        rmdir "$TEMP_DIR"
        return 1
    fi
}

# 应用配置（学习post-fs-data.sh的完整挂载逻辑）
apply_config() {
    log "开始应用证书配置..."
    
    # 检查root权限
    if [ "$(id -u)" != "0" ]; then
        log "错误: 需要root权限才能应用配置"
        echo "Root permission required"
        return 1
    fi
    
    local success=true
    
    # 设置证书文件权限
    log "设置证书文件权限..."
    chown -R 0:0 "$CERT_DIR" 2>/dev/null || true
    
    # 根据Android版本选择挂载策略
    if [ "$ANDROID_SDK" -ge 34 ] && [ -d /apex/com.android.conscrypt/cacerts ]; then
        log "检测到Android 14+，使用APEX挂载模式"
        
        # 挂载APEX证书目录
        if ! mount_apex_certs; then
            log "APEX证书挂载失败"
            success=false
        fi
        
        # 同时处理传统目录（兼容性）
        mount_legacy_certs
        
    else
        log "检测到Android 13及以下，使用传统挂载模式"
        
        # 挂载传统证书目录
        if ! mount_legacy_certs; then
            log "传统证书挂载失败"
            success=false
        fi
    fi
    
    if [ "$success" = true ]; then
        log "证书配置应用成功"
        echo "Configuration applied successfully"
        
        # 显示挂载状态
        log "当前挂载状态:"
        if [ -d /apex/com.android.conscrypt/cacerts ]; then
            local apex_count=$(ls -1 /apex/com.android.conscrypt/cacerts/ 2>/dev/null | wc -l)
            log "APEX证书目录: $apex_count 个证书"
        fi
        
        local system_count=$(ls -1 /system/etc/security/cacerts/ 2>/dev/null | wc -l)
        log "系统证书目录: $system_count 个证书"
        
        return 0
    else
        log "证书配置应用失败"
        echo "Configuration failed"
        return 1
    fi
}

# 获取目录信息
get_paths() {
    echo "{"
    echo "  \"moddir\": \"$MODDIR\","
    echo "  \"cert_dir\": \"$CERT_DIR\","
    echo "  \"apex_cert_dir\": \"$APEX_CERT_DIR\","
    echo "  \"config_dir\": \"$CONFIG_DIR\","
    echo "  \"enabled_file\": \"$ENABLED_FILE\","
    echo "  \"info_file\": \"$INFO_FILE\","
    echo "  \"android_sdk\": \"$ANDROID_SDK\","
    echo "  \"need_apex_mount\": \"$NEED_APEX_MOUNT\","
    echo "  \"real_moddir\": \"/data/adb/modules/CertificateManager\","
    echo "  \"real_cert_dir\": \"/data/adb/modules/CertificateManager/system/etc/security/cacerts\","
    echo "  \"real_apex_cert_dir\": \"/data/adb/modules/CertificateManager/apex/com.android.conscrypt/cacerts\","
    echo "  \"real_config_dir\": \"/data/adb/modules/CertificateManager/config\""
    echo "}"
}

# 获取状态和所有证书信息
get_status() {
    local format="${1:-json}"
    
    if [ "$format" = "certificates" ]; then
        # 返回详细的证书列表
        echo "{"
        echo "  \"certificates\": ["
        
        local first=true
        for cert_file in "$CERT_DIR"/*.0; do
            [ -f "$cert_file" ] || continue
            
            local cert_name="$(basename "$cert_file")"
            local hash="${cert_name%.0}"
            local enabled="false"
            local original_path="unknown"
            local added_time="unknown"
            
            # 检查是否启用（支持.0文件名、哈希或原始文件名）
            if grep -q "$cert_name\|${cert_name%.0}\|$hash" "$ENABLED_FILE" 2>/dev/null; then
                enabled="true"
            else
                # 特殊映射：reqable.pem -> d4a357b0
                case "$hash" in
                    "d4a357b0")
                        if grep -q "reqable.pem\|reqable" "$ENABLED_FILE" 2>/dev/null; then
                            enabled="true"
                        fi
                        ;;
                esac
            fi
            
            # 从元数据文件获取详细信息
            if [ -f "$INFO_FILE" ]; then
                local info_line=$(grep -A 5 "\"hash\": \"$hash\"" "$INFO_FILE" 2>/dev/null)
                if [ -n "$info_line" ]; then
                    original_path=$(echo "$info_line" | grep "original_path" | sed 's/.*"original_path": "\([^"]*\)".*/\1/' 2>/dev/null)
                    added_time=$(echo "$info_line" | grep "added_time" | sed 's/.*"added_time": "\([^"]*\)".*/\1/' 2>/dev/null)
                fi
            fi
            
            # 如果没有元数据，尝试根据文件名推断
            if [ "$original_path" = "unknown" ]; then
                case "$hash" in
                    "243f0bfb") original_path="/storage/emulated/0/Download/243f0bfb.0" ;;
                    "d4a357b0") original_path="certs/reqable.pem" ;;
                    *) original_path="system/builtin" ;;
                esac
            fi
            
            if [ "$first" != "true" ]; then
                echo ","
            fi
            
            echo "    {"
            echo "      \"id\": \"$cert_name\","
            echo "      \"name\": \"Certificate ($hash)\","
            echo "      \"hash\": \"$hash\","
            echo "      \"enabled\": $enabled,"
            echo "      \"original_path\": \"$original_path\","
            echo "      \"added_time\": \"$added_time\","
            echo "      \"file_size\": $(stat -c%s "$cert_file" 2>/dev/null || echo 0)"
            echo "    }"
            
            first="false"
        done
        
        echo "  ],"
        echo "  \"total_certs\": $(ls "$CERT_DIR"/*.0 2>/dev/null | wc -l),"
        echo "  \"enabled_certs\": $(if [ -s "$ENABLED_FILE" ]; then grep -c . "$ENABLED_FILE" 2>/dev/null; else echo 0; fi),"
        echo "  \"status\": \"active\""
        echo "}"
    else
        # 返回简单状态
        echo "{"
        echo "  \"total_certs\": $(ls "$CERT_DIR"/*.0 2>/dev/null | wc -l),"
        echo "  \"enabled_certs\": $(if [ -s "$ENABLED_FILE" ]; then grep -c . "$ENABLED_FILE" 2>/dev/null; else echo 0; fi),"
        echo "  \"cert_dir\": \"$CERT_DIR\","
        echo "  \"status\": \"active\""
        echo "}"
    fi
}

# 检查挂载状态
check_mount_status() {
    log "检查证书挂载状态..."
    echo "=== 证书挂载状态 ==="
    
    # 检查Android版本
    echo "Android SDK版本: $ANDROID_SDK"
    echo "需要APEX挂载: $NEED_APEX_MOUNT"
    echo ""
    
    # 检查传统证书目录
    echo "传统证书目录 (/system/etc/security/cacerts):"
    if [ -d /system/etc/security/cacerts ]; then
        local system_count=$(ls -1 /system/etc/security/cacerts/ 2>/dev/null | wc -l)
        echo "  状态: 存在"
        echo "  证书数量: $system_count"
        echo "  模块证书: $(ls -1 "$CERT_DIR"/ 2>/dev/null | wc -l)"
    else
        echo "  状态: 不存在"
    fi
    echo ""
    
    # 检查APEX证书目录
    echo "APEX证书目录 (/apex/com.android.conscrypt/cacerts):"
    if [ -d /apex/com.android.conscrypt/cacerts ]; then
        local apex_count=$(ls -1 /apex/com.android.conscrypt/cacerts/ 2>/dev/null | wc -l)
        echo "  状态: 存在"
        echo "  证书数量: $apex_count"
        
        # 检查是否为tmpfs挂载
        local mount_info=$(mount | grep "/apex/com.android.conscrypt/cacerts" | head -1)
        if [ -n "$mount_info" ]; then
            echo "  挂载信息: $mount_info"
        else
            echo "  挂载信息: 默认挂载"
        fi
    else
        echo "  状态: 不存在"
    fi
    echo ""
    
    # 检查相关进程
    echo "相关进程:"
    echo "  PID 1: $(if [ -d /proc/1/ns/mnt ]; then echo "存在"; else echo "不存在"; fi)"
    local zygote_pids=$(pgrep zygote 2>/dev/null)
    local zygote64_pids=$(pgrep zygote64 2>/dev/null)
    echo "  Zygote进程: $zygote_pids"
    echo "  Zygote64进程: $zygote64_pids"
}

# 卸载挂载
unmount_certs() {
    log "卸载证书挂载..."
    
    # 检查root权限
    if [ "$(id -u)" != "0" ]; then
        log "错误: 需要root权限才能卸载"
        echo "Root permission required"
        return 1
    fi
    
    local success=true
    
    # 卸载APEX目录（如果是bind mount）
    if mount | grep -q "/apex/com.android.conscrypt/cacerts.*bind"; then
        log "卸载APEX证书目录绑定挂载"
        if umount /apex/com.android.conscrypt/cacerts 2>/dev/null; then
            log "APEX证书目录卸载成功"
        else
            log "警告: APEX证书目录卸载失败"
            success=false
        fi
    fi
    
    # 清理临时目录
    local temp_dirs=$(ls -d /data/local/tmp/cacerts-copy-* 2>/dev/null)
    if [ -n "$temp_dirs" ]; then
        log "清理临时目录..."
        for temp_dir in $temp_dirs; do
            umount "$temp_dir" 2>/dev/null || true
            rmdir "$temp_dir" 2>/dev/null || true
        done
    fi
    
    if [ "$success" = true ]; then
        log "证书挂载卸载成功"
        echo "Unmount successful"
    else
        log "证书挂载卸载失败"
        echo "Unmount failed"
    fi
}

# 主程序
case "${1:-help}" in
    "add")
        if [ -z "$2" ]; then
            echo "用法: $0 add <证书文件路径>"
            exit 1
        fi
        add_cert "$2"
        ;;
    "remove"|"delete")
        if [ -z "$2" ]; then
            echo "用法: $0 remove <证书ID>"
            exit 1
        fi
        remove_cert "$2"
        ;;
    "list")
        list_certs
        ;;
    "apply")
        apply_config
        ;;
    "status")
        get_status
        ;;
    "certificates"|"certs")
        get_status "certificates"
        ;;
    "paths")
        get_paths
        ;;
    "mount-status"|"mount")
        check_mount_status
        ;;
    "unmount")
        unmount_certs
        ;;
    "help"|*)
        echo "证书管理器 v3.0 (集成挂载功能)"
        echo ""
        echo "用法: $0 <命令> [参数]"
        echo ""
        echo "命令:"
        echo "  add <文件>        添加证书文件"
        echo "  remove <ID>       删除证书"
        echo "  list             列出所有证书"
        echo "  certificates     获取详细证书信息(JSON)"
        echo "  apply            应用配置并挂载证书"
        echo "  mount-status     检查挂载状态"
        echo "  unmount          卸载证书挂载"
        echo "  status           获取状态信息"
        echo "  help             显示此帮助"
        echo ""
        echo "示例:"
        echo "  $0 add /sdcard/Download/mycert.pem"
        echo "  $0 apply                    # 应用配置并挂载"
        echo "  $0 mount-status            # 检查挂载状态"
        echo "  $0 remove 243f0bfb"
        echo "  $0 certificates"
        ;;
esac