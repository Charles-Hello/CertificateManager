#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import subprocess
import hashlib
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

# 导入证书信息管理器
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cert_info_manager import CertInfoManager

# 配置
PORT = 18888
MODDIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEBROOT = os.path.join(MODDIR, 'webroot')
CERT_MANAGER = os.path.join(MODDIR, 'scripts', 'cert_manager.sh')

class CertManagerHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        print(f"[{self.log_date_time_string()}] {format % args}")
    
    def do_GET(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        print(f"收到GET请求: {path}")
        
        if path.startswith('/api/certificates'):
            self.handle_api_certificates()
        elif path.startswith('/api/paths'):
            self.handle_api_paths()
        else:
            self.handle_static_file(path)
    
    def do_POST(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        print(f"收到POST请求: {path}")
        
        if path.startswith('/api/add_cert'):
            self.handle_api_add_cert()
        elif path.startswith('/api/remove_cert'):
            self.handle_api_remove_cert()
        elif path.startswith('/api/apply_config'):
            self.handle_api_apply_config()
        else:
            self.send_404()
    
    def handle_api_certificates(self):
        try:
            # 直接使用CertInfoManager获取证书信息
            info_file = os.path.join(MODDIR, 'config', 'cert_info.json')
            manager = CertInfoManager(info_file)
            certificates = manager.list_certificates()
            stats = manager.get_stats()
            
            response_data = json.dumps({
                "certificates": certificates,
                "stats": stats
            }, ensure_ascii=False, indent=2)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            self.wfile.write(response_data.encode('utf-8'))
            
        except Exception as e:
            error_response = f'{{"certificates":[],"error":"服务器错误: {str(e)}"}}'
            self.send_response(500)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.end_headers()
            self.wfile.write(error_response.encode('utf-8'))
    
    def handle_api_paths(self):
        try:
            result = subprocess.run(['sh', CERT_MANAGER, 'paths'], 
                                  capture_output=True, text=True, timeout=30)
            if result.returncode == 0:
                response_data = result.stdout.strip()
                if not response_data:
                    response_data = '{"error":"命令执行成功但无输出"}'
            else:
                response_data = '{"error":"命令执行失败"}'
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Cache-Control', 'no-cache')
            self.end_headers()
            self.wfile.write(response_data.encode('utf-8'))
            
        except Exception as e:
            error_response = f'{{"error":"服务器错误: {str(e)}"}}'
            self.send_response(500)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.end_headers()
            self.wfile.write(error_response.encode('utf-8'))
    
    def handle_static_file(self, path):
        # 默认文件是 index.html
        if path == '/':
            file_path = os.path.join(WEBROOT, 'index.html')
        else:
            file_path = os.path.join(WEBROOT, path.lstrip('/'))
        
        try:
            if os.path.exists(file_path) and os.path.isfile(file_path):
                with open(file_path, 'rb') as f:
                    content = f.read()
                
                # 确定内容类型
                if file_path.endswith('.html'):
                    content_type = 'text/html; charset=utf-8'
                elif file_path.endswith('.css'):
                    content_type = 'text/css; charset=utf-8'
                elif file_path.endswith('.js'):
                    content_type = 'application/javascript; charset=utf-8'
                else:
                    content_type = 'text/plain; charset=utf-8'
                
                self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(len(content)))
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()
                self.wfile.write(content)
            else:
                self.send_404()
                
        except Exception as e:
            print(f"文件读取错误: {e}")
            self.send_500()
    
    def send_404(self):
        self.send_response(404)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.end_headers()
        self.wfile.write(b'404 - File not found')
    
    def send_500(self):
        self.send_response(500)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.end_headers()
        self.wfile.write(b'500 - Internal server error')
    
    def handle_api_add_cert(self):
        try:
            # 读取POST数据
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                post_data = self.rfile.read(content_length).decode('utf-8')
                data = json.loads(post_data)
                cert_path = data.get('cert_path', '')
                
                if not cert_path:
                    response_data = '{"success": false, "error": "证书路径不能为空"}'
                else:
                    # 验证证书文件是否存在且有效
                    if not os.path.exists(cert_path):
                        response_data = '{"success": false, "error": "证书文件不存在"}'
                    else:
                        # 检查证书是否已经存在
                        cert_name = os.path.basename(cert_path)
                        info_file = os.path.join(MODDIR, 'config', 'cert_info.json')
                        manager = CertInfoManager(info_file)
                        
                        # 检查是否已经添加过相同的证书文件
                        existing_certs = manager.list_certificates()
                        cert_exists = False
                        for existing_cert in existing_certs:
                            if existing_cert.get('original_path') == cert_path:
                                cert_exists = True
                                response_data = f'{{"success": false, "error": "证书 {cert_name} 已经存在，无需重复添加"}}'
                                break
                        
                        if not cert_exists:
                            # 调用证书管理脚本添加证书 - 遵循post-fs-data.sh的思路
                            result = subprocess.run(['sh', CERT_MANAGER, 'add', cert_path], 
                                                  capture_output=True, text=True, timeout=30)
                            if result.returncode == 0:
                                # 直接调用cert_info_manager.py更新证书元数据
                                self._update_cert_metadata(cert_path)
                                
                                # 检查是否需要在双目录中创建证书 (遵循post-fs-data.sh逻辑)
                                android_version = self._get_android_version()
                                apex_needed = android_version >= 34
                                
                                response_data = f'{{"success": true, "message": "证书添加成功", "apex_support": {str(apex_needed).lower()}, "note": "重启后生效，将按post-fs-data.sh逻辑挂载"}}'
                            else:
                                error_msg = result.stderr.strip() or result.stdout.strip() or "证书添加失败"
                                response_data = f'{{"success": false, "error": "{error_msg}"}}'
            else:
                response_data = '{"success": false, "error": "无效的请求数据"}'
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(response_data.encode('utf-8'))
            
        except Exception as e:
            error_response = f'{{"success": false, "error": "服务器错误: {str(e)}"}}'
            self.send_response(500)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.end_headers()
            self.wfile.write(error_response.encode('utf-8'))
    
    def handle_api_remove_cert(self):
        try:
            # 读取POST数据
            content_length = int(self.headers.get('Content-Length', 0))
            if content_length > 0:
                post_data = self.rfile.read(content_length).decode('utf-8')
                data = json.loads(post_data)
                cert_id = data.get('cert_id', '')
                
                if not cert_id:
                    response_data = '{"success": false, "error": "证书ID不能为空"}'
                else:
                    # 调用证书管理脚本删除证书
                    result = subprocess.run(['sh', CERT_MANAGER, 'remove', cert_id], 
                                          capture_output=True, text=True, timeout=30)
                    if result.returncode == 0:
                        # 直接调用cert_info_manager.py删除证书元数据
                        self._remove_cert_metadata(cert_id)
                        response_data = '{"success": true, "message": "证书删除成功"}'
                    else:
                        error_msg = result.stderr.strip() or "证书删除失败"
                        response_data = f'{{"success": false, "error": "{error_msg}"}}'
            else:
                response_data = '{"success": false, "error": "无效的请求数据"}'
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(response_data.encode('utf-8'))
            
        except Exception as e:
            error_response = f'{{"success": false, "error": "服务器错误: {str(e)}"}}'
            self.send_response(500)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.end_headers()
            self.wfile.write(error_response.encode('utf-8'))
    
    def handle_api_apply_config(self):
        try:
            # 应用配置 - 说明当前证书需要重启才能按post-fs-data.sh逻辑生效
            
            # 首先获取当前系统状态
            apex_supported = self._check_apex_support()
            android_version = self._get_android_version()
            
            # 检查证书目录状态
            cert_count = self._count_certificates()
            
            if cert_count == 0:
                response_data = '{"success": false, "error": "没有证书需要应用"}'
            else:
                # 调用证书管理脚本应用配置（主要是验证）
                result = subprocess.run(['sh', CERT_MANAGER, 'apply'], 
                                      capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0:
                    mount_strategy = "APEX tmpfs挂载" if apex_supported else "传统overlay挂载"
                    response_data = f'''{{
                        "success": true, 
                        "message": "配置已准备完成，重启后生效",
                        "details": {{
                            "mount_strategy": "{mount_strategy}",
                            "android_version": {android_version},
                            "apex_support": {str(apex_supported).lower()},
                            "cert_count": {cert_count},
                            "note": "证书将在下次重启时由post-fs-data.sh自动挂载到系统"
                        }}
                    }}'''
                else:
                    error_msg = result.stderr.strip() or result.stdout.strip() or "配置验证失败"
                    response_data = f'{{"success": false, "error": "{error_msg}"}}'
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(response_data.encode('utf-8'))
            
        except Exception as e:
            error_response = f'{{"success": false, "error": "服务器错误: {str(e)}"}}'
            self.send_response(500)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.end_headers()
            self.wfile.write(error_response.encode('utf-8'))
    
    def _count_certificates(self):
        """统计证书数量"""
        try:
            cert_dir = os.path.join(MODDIR, 'system', 'etc', 'security', 'cacerts')
            if os.path.exists(cert_dir):
                return len([f for f in os.listdir(cert_dir) if f.endswith('.0')])
        except:
            pass
        return 0
    
    def _validate_cert_file(self, cert_path):
        """验证证书文件格式 - 遵循post-fs-data.sh的检查思路"""
        try:
            with open(cert_path, 'r') as f:
                content = f.read()
                # 检查是否包含证书标记 (类似post-fs-data.sh中的检查)
                return "BEGIN CERTIFICATE" in content and "END CERTIFICATE" in content
        except:
            return False
    
    def _get_android_version(self):
        """获取Android版本 - 模拟post-fs-data.sh中的版本检测"""
        try:
            result = subprocess.run(['getprop', 'ro.build.version.sdk'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                return int(result.stdout.strip())
        except:
            pass
        return 0
    
    def _check_apex_support(self):
        """检查APEX支持 - 遵循post-fs-data.sh的检测逻辑"""
        return os.path.exists('/apex/com.android.conscrypt/cacerts')
    
    def _validate_cert_content(self, content):
        """验证证书内容格式 - 遵循post-fs-data.sh的验证思路"""
        return "BEGIN CERTIFICATE" in content and "END CERTIFICATE" in content
    
    def _generate_cert_hash(self, cert_path):
        """生成证书hash - 遵循Android证书命名规则"""
        try:
            # 读取证书内容并计算hash
            with open(cert_path, 'rb') as f:
                cert_content = f.read()
            return hashlib.sha256(cert_content).hexdigest()[:8]
        except:
            return None
    
    def _update_cert_metadata(self, cert_path):
        """直接使用CertInfoManager更新证书元数据"""
        try:
            cert_name = os.path.basename(cert_path)
            cert_hash = self._generate_cert_hash(cert_path)
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            info_file = os.path.join(MODDIR, 'config', 'cert_info.json')
            
            if cert_hash:
                # 直接使用CertInfoManager类
                manager = CertInfoManager(info_file)
                # 使用原始文件名而不是计算的hash
                filename = cert_name  # cert_name 是 os.path.basename(cert_path)
                
                if manager.add_certificate(cert_hash, filename, cert_path, True, timestamp):
                    print(f"证书元数据更新成功: {cert_name} -> {filename}")
                else:
                    print(f"证书元数据更新失败: {cert_name}")
            else:
                print(f"无法生成证书hash: {cert_name}")
        except Exception as e:
            print(f"更新证书元数据时出错: {e}")
    
    def _remove_cert_metadata(self, cert_id):
        """直接使用CertInfoManager删除证书元数据"""
        try:
            info_file = os.path.join(MODDIR, 'config', 'cert_info.json')
            manager = CertInfoManager(info_file)
            
            # 尝试按filename删除（cert_id可能是filename）
            if manager.remove_certificate(cert_id, by_filename=True):
                print(f"证书元数据删除成功: {cert_id}")
            else:
                # 如果按filename删除失败，尝试按hash删除
                if manager.remove_certificate(cert_id, by_filename=False):
                    print(f"证书元数据删除成功 (按hash): {cert_id}")
                else:
                    print(f"证书元数据删除失败: 未找到证书 {cert_id}")
        except Exception as e:
            print(f"删除证书元数据时出错: {e}")

def main():
    print(f"启动证书管理器Web服务器")
    print(f"端口: {PORT}")
    print(f"模块目录: {MODDIR}")
    print(f"Web根目录: {WEBROOT}")
    print(f"证书管理器: {CERT_MANAGER}")
    print(f"访问: http://localhost:{PORT}")
    
    # 检查必要文件
    if not os.path.exists(os.path.join(WEBROOT, 'index.html')):
        print(f"错误: {os.path.join(WEBROOT, 'index.html')} 不存在")
        sys.exit(1)
    
    server = HTTPServer(('', PORT), CertManagerHandler)
    print("服务器启动完成，等待连接...")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务器已停止")
        server.server_close()

if __name__ == '__main__':
    main()