#!/system/bin/sh

# 简化的证书管理器Web服务器
MODDIR=${0%/*}/..
WEBROOT="$MODDIR/webroot"
CERT_MANAGER="$MODDIR/scripts/cert_manager.sh"
PORT=18888

log() {
    echo "[$(date '+%H:%M:%S')] $1"
}

start_server() {
    log "启动证书管理器Web服务器"
    log "端口: $PORT"
    log "访问: http://localhost:$PORT"
    
    if [ ! -f "$WEBROOT/index.html" ]; then
        log "错误: $WEBROOT/index.html 不存在"
        exit 1
    fi
    
    if [ ! -x "$CERT_MANAGER" ]; then
        chmod +x "$CERT_MANAGER" 2>/dev/null || true
    fi
    
    # 停止可能存在的服务
    pkill -f "python.*simple_server.py" 2>/dev/null || true
    pkill -f "nc.*$PORT" 2>/dev/null || true
    sleep 1
    
    # 使用Python服务器
    PYTHON_SERVER="$MODDIR/scripts/simple_server.py"
    
    # 查找可用的Python
    PYTHON_BIN=""
    for python_path in \
        "/data/data/com.termux/files/usr/bin/python3" \
        "/system/bin/python3" \
        "/system/bin/python" \
        "$(which python3 2>/dev/null)" \
        "$(which python 2>/dev/null)"; do
        if [ -x "$python_path" ] 2>/dev/null; then
            PYTHON_BIN="$python_path"
            break
        fi
    done
    
    if [ -n "$PYTHON_BIN" ] && [ -f "$PYTHON_SERVER" ]; then
        log "使用Python服务器启动: $PYTHON_BIN"
        chmod +x "$PYTHON_SERVER" 2>/dev/null || true
        "$PYTHON_BIN" "$PYTHON_SERVER"
    else
        log "错误: Python不可用或服务器脚本不存在"
        log "Python路径: $PYTHON_BIN"
        log "服务器脚本: $PYTHON_SERVER"
        exit 1
    fi
}

stop_server() {
    log "停止Web服务器..."
    pkill -f "python.*simple_server.py" 2>/dev/null || true
    pkill -f "nc.*$PORT" 2>/dev/null || true
    pkill -f "web_server.sh" 2>/dev/null || true
    log "服务器已停止"
}

case "${1:-start}" in
    "start")
        start_server
        ;;
    "stop")
        stop_server
        ;;
    "restart")
        stop_server
        sleep 2
        start_server
        ;;
    *)
        echo "用法: $0 {start|stop|restart}"
        exit 1
        ;;
esac