#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试 simple_server.py 中的直接调用功能
"""

import os
import sys
import json
from datetime import datetime

# 添加scripts目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'scripts'))
from cert_info_manager import CertInfoManager

def test_cert_info_manager():
    """测试CertInfoManager的基本功能"""
    print("=== 测试CertInfoManager ===")
    
    # 测试文件路径
    test_info_file = os.path.join(os.path.dirname(__file__), 'config', 'test_cert_info.json')
    
    try:
        # 创建管理器实例
        manager = CertInfoManager(test_info_file)
        print("✓ CertInfoManager 实例创建成功")
        
        # 添加测试证书
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        result1 = manager.add_certificate("hash001", "test1.0", "/test/path/cert1.pem", True, timestamp)
        result2 = manager.add_certificate("hash002", "test2.0", "/test/path/cert2.pem", True, timestamp)
        result3 = manager.add_certificate("hash003", "test3.0", "/test/path/cert3.pem", False, timestamp)
        
        if result1 and result2 and result3:
            print("✓ 添加多个证书成功")
        else:
            print("✗ 添加证书失败")
            return False
        
        # 获取证书列表
        certificates = manager.list_certificates()
        print(f"✓ 获取证书列表成功，共 {len(certificates)} 个证书")
        
        # 获取统计信息
        stats = manager.get_stats()
        print(f"✓ 统计信息: 总数 {stats['total']}，启用 {stats['enabled']}")
        
        # 测试按filename删除
        if manager.remove_certificate("test1.0", by_filename=True):
            print("✓ 按文件名删除证书成功")
        else:
            print("✗ 按文件名删除证书失败")
            return False
        
        # 验证删除结果
        remaining = manager.list_certificates()
        if len(remaining) == 2:
            print(f"✓ 删除后剩余 {len(remaining)} 个证书")
        else:
            print(f"✗ 删除后证书数量不正确: {len(remaining)}")
            return False
        
        print("✓ 所有测试通过!")
        
        # 显示最终的JSON内容
        print("\n=== 最终的证书信息 ===")
        print(json.dumps({"certificates": remaining}, ensure_ascii=False, indent=2))
        
        return True
        
    except Exception as e:
        print(f"✗ 测试过程中出错: {e}")
        return False
    finally:
        # 清理测试文件
        if os.path.exists(test_info_file):
            os.remove(test_info_file)
            print("✓ 清理测试文件完成")

def test_simple_server_methods():
    """测试simple_server.py中的方法"""
    print("\n=== 测试Simple Server方法 ===")
    
    try:
        # 模拟simple_server.py中的方法
        import hashlib
        
        def _generate_cert_hash(cert_content):
            """模拟生成证书hash"""
            return hashlib.sha256(cert_content.encode()).hexdigest()[:8]
        
        # 测试hash生成
        test_content = "test certificate content"
        test_hash = _generate_cert_hash(test_content)
        print(f"✓ 证书hash生成成功: {test_hash}")
        
        # 测试元数据更新逻辑
        info_file = os.path.join(os.path.dirname(__file__), 'config', 'cert_info.json')
        manager = CertInfoManager(info_file)
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        filename = f"{test_hash}.0"
        
        if manager.add_certificate(test_hash, filename, "/test/cert/path", True, timestamp):
            print("✓ 模拟证书元数据更新成功")
        else:
            print("✗ 模拟证书元数据更新失败")
            return False
        
        print("✓ Simple Server方法测试通过!")
        return True
        
    except Exception as e:
        print(f"✗ Simple Server方法测试失败: {e}")
        return False

if __name__ == "__main__":
    print("开始集成测试...")
    
    success1 = test_cert_info_manager()
    success2 = test_simple_server_methods()
    
    if success1 and success2:
        print("\n🎉 所有集成测试通过!")
        sys.exit(0)
    else:
        print("\n❌ 部分测试失败!")
        sys.exit(1)